#!/bin/bash

export BASE_DIR=$(dirname $0)
mkdir /tmp/kafka-manager && \
	cd /tmp/kafka-manager && \
	wget https://github.com/yahoo/kafka-manager/archive/1.3.0.8.zip && \
    jar -xf 1.3.0.8.zip && \
    cd kafka-manager-1.3.0.8 && \
    bash ./sbt clean dist
cd $BASE_DIR
cp /tmp/kafka-manager/kafka-manager-1.3.0.8/target/universal/kafka-manager-1.3.0.8.zip .
rm -rf /tmp/kafka-manager
docker build -t sabarishdocker/kafka-manager:1.3.0.8 .
#docker login
#docker push sabarishdocker/kafka-manager:1.3.0.8