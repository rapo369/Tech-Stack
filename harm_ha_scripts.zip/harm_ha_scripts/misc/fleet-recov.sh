[Service]
Environment=ETCD_HEARTBEAT_INTERVAL=600
Environment=ETCD_ELECTION_TIMEOUT=6000

sudo cat -> /tmp/99-specify-vars.conf << EOF
[Service]
Environment=FLEET_ENGINE_RECONCILE_INTERVAL=10
Environment=FLEET_ETCD_REQUEST_TIMEOUT=5
Environment=FLEET_AGENT_TTL=120s
EOF
sudo cp /tmp/99-specify-vars.conf /run/systemd/system/fleet.service.d/99-specify-vars.conf
sudo systemctl daemon-reload
sudo systemctl restart fleet.service
