#!/bin/bash

export CONNECTOR_IP=$(fleetctl list-units|grep connector|head -1|awk '{print $2}'|awk -F/ '{print $2}')
echo "One event persister IP: $CONNECTOR_IP"
echo "Current list of event persisters"
curl -X GET -H "Content-Type: application/json"  http://$CONNECTOR_IP:8083/connectors
export MYSQL_IP=$(fleetctl list-units|grep mysql|awk '{print $2}'|awk -F/ '{print $2}')
sed -i -e "s/\${MYSQL_IP}/$MYSQL_IP/" s3connectorconfig.json
echo "Deploying s3 event persister streaming app"
curl -X POST -H "Content-Type: application/json" --data @s3connectorconfig.json http://$CONNECTOR_IP:8083/connectors
echo "Sleeping a few seconds"
sleep 5
echo "Current list of event persisters"
curl -X GET -H "Content-Type: application/json"  http://$CONNECTOR_IP:8083/connectors
echo "creating connector schema for mysql"

etcdctl --endpoints "http://10.0.0.6:2379,http://10.0.0.7:2379,http://10.0.0.8:2379" set /ips/mysql "$(echo $MYSQL_IP)"
docker run -it --rm mysql/mysql-server:5.7.12 sh -c "exec mysql -h$MYSQL_IP -P3306 -uroot -p2#4DSR#W@D --execute 'create schema if not exists kafkametrics'"
docker run -it --rm mysql/mysql-server:5.7.12 sh -c "exec mysql -h$MYSQL_IP -P3306 -uroot -p2#4DSR#W@D --execute 'SET GLOBAL max_connections = 1000;'"