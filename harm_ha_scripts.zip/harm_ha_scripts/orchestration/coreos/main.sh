#!/bin/bash

sh ./start-graylog2.sh

sh ./start-zookeeper.sh harman dev zookeeper@{1..3}.service

sh ./start-kafka.sh harman dev kafka@{1..3}.service

sh ./start-kafkamgr.sh harman dev kafkamgr@1.service

#sh ./start-etl.sh

#sh ./start-mysql.sh

#sh ./start-connector.sh

#sh ./deploy-connector.sh

#sh ./start-metricsconnector.sh

#sh ./deploy-metrics-connector.sh

sh ./start-mqtt.sh harman dev mqtt@1.service

sh ./start-mqtt_kafka_connector.sh harman dev mqtt_kafka_connector@1.service

#sh ./start-https.sh 

#sh ./start-haastreaming.sh

sh ./start-redis.sh harman dev redis@1.service

sh ./start-kafka_redis_connector.sh harman dev kafka_redis_connector@1.service

sh ./start-auth-and-association.sh

sh ./start-mongo.sh harman dev kafka_mongodb_connect@1.service

sh ./start-api.sh harman dev api@1.service

sh ./start-jenkins.sh

sh ./start-dtc_data_loader.sh harman dev dtc_data_loader@1.service

sh ./start-kafka-s3-legacy-connector.sh harman dev kafka-s3-legacy-connector@{1..2}.service

sh ./start-services-health-check.sh