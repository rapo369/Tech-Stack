#!/bin/bash
tenant=${1}
env=${2}
instance=${3}
service_instance=${tenant}_${env}_${instance}
echo "mongo service: $service_instance"
db_name=harman1${env}
echo "db name : $db_name"
fleetctl ssh -A $service_instance "docker exec -i ${tenant}_${env}_mongod mongo admin -u 'admin' -p '70tJu2dy43lz' --eval 'db.grantRolesToUser(\"haa\",[{ role: \"dbOwner\", db: \"$db_name\" }]);'"
fleetctl ssh -A $service_instance "docker exec -i ${tenant}_${env}_mongod mongo admin -u 'admin' -p '70tJu2dy43lz' --eval 'db.getUser(\"haa\");'"
