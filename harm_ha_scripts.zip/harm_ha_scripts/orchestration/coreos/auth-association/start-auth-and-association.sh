#!/bin/bash
TENANT=${1}
ENV=${2}
SERVICE=${3}
#instance=${3}

# service start up sequence to follow, postgres, auth, user-auth, association, device-info
echo "Starting ${TENANT}_${ENV}_${SERVICE} service."
fleetctl destroy ${TENANT}_${ENV}_${SERVICE}@1.service
fleetctl submit ${TENANT}_${ENV}_${SERVICE}@1.service
fleetctl start ${TENANT}_${ENV}_${SERVICE}@1.service

rc=0
while [ $rc -lt 1 ]
do
echo "Zzzzzz (*yawns*)"
sleep 5
rc=$(fleetctl list-units|grep -E "${TENANT}_${ENV}_${SERVICE}@..service"|grep running|wc -l)
fleetctl list-units|grep -E "${TENANT}_${ENV}_${SERVICE}@..service"
done
echo "DEPLOYMENT COMPLETE for ${TENANT}_${ENV}_${SERVICE} service."

echo -e "\n\n\ncurrent status of the services"
fleetctl list-units|grep -E '*_auth@..service|*_association@..service|*_device_info@..service|*_user_auth@..service|*_hcp_postgres@..service'
