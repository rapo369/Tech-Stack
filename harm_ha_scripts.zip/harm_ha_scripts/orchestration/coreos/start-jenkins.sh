#!/bin/bash

echo "Shutting down Jenkins"
fleetctl destroy jenkins@1.service
if [ $? == 0 ] ; then
    echo "Sleeping 60 seconds..."
    sleep 60
fi

echo "Starting Jenkins"
fleetctl submit jenkins@1.service
fleetctl start jenkins@1.service
rc=0
iterations=1
max_tries=10
while [ $rc -lt 1 ]
do
echo "Zzzzzz (*yawns*)"
sleep 5
rc=$(fleetctl list-units | grep jenkins@.*.service | grep running | wc -l)
fleetctl list-units | grep jenkins@.*.service

iterations=`expr $iterations + 1`
if [ "$iterations" -gt "$max_tries" ];then
   echo "start script exceeded max number of retries will exit"
   exit 1
fi
 
done
echo "Jenkins is up and running."
sleep 30;
echo "logs for jenkins@1.service-----------------"
fleetctl journal -lines 20 jenkins@1.service