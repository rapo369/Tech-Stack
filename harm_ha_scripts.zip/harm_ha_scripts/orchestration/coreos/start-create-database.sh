#!/bin/bash

tenant=${1}
env=${2}
instance=${3}

service_instance=${tenant}_${env}_${instance}

echo "Shutting down create_database service ${service_instance}"
fleetctl destroy ${service_instance}
if [ $? == 0 ] ; then
    sleep 5; 
fi

echo "Starting create_database service"
fleetctl submit ${service_instance}
fleetctl start ${service_instance}

unit_name=`echo $service_instance | cut -d '@' -f 1`
no_of_units=`echo $service_instance | awk -v FS="({|})" '{print $2}' | cut -d '.' -f 3`
no_of_units="${no_of_units#"${var%%[![:space:]]*}"}"
if [ "$no_of_units" == "" ];then
   no_of_units=1
fi
 
rc=0
iterations=1
max_tries=10 
while [ $rc -lt $no_of_units ]
do
echo "Zzzzzz (*yawns*)"
rc=$(fleetctl list-units|grep ${unit_name}@| grep running|wc -l)
fleetctl list-units|grep ${unit_name}@
iterations=`expr $iterations + 1`
if [ "$iterations" -gt "$max_tries" ];then
   echo "start script exceeded max number of retries will exit"
   exit 1
fi

done
echo "create_database script is executed successfully by ${service_instance}."

