tenant=${1}
env=${2}
metaType=${3}
pemFileName=${4}

if [ -z "$tenant" ] || [ -z "$env" ] || [ -z "$metaType" ] || [ -z "$pemFileName" ]  ;
then
scriptUsage="Script usage:  $0 harman dev api harpem.pem"
  echo "one or more required arguments missing for $0 script; $scriptUsage"
  exit 1
fi

# *********STEP 1 COPY KEYFILE TO MONGO CONFIGURATION NODES ************

./meta-type-discovery.sh $metaType
if [ $? -eq 1 ]
then
echo "Exiting $metaType creation"
 exit 1
fi
sleep 10;

etcd1=`fleetctl list-machines|grep etcd|awk '{print $2}'| awk  NR==1'{print $1}'`
etcd2=`fleetctl list-machines|grep etcd|awk '{print $2}'| awk  NR==2'{print $1}'`
etcd3=`fleetctl list-machines|grep etcd|awk '{print $2}'| awk  NR==3'{print $1}'`

count=""$(etcdctl --endpoints "http://$etcd1:2379,http://$etcd2:2379,http://$etcd3:2379" get /ips/$metaType | wc -w)"";

./start-mongo_qr_$metaType.sh ${tenant} ${env} 1..$count all
