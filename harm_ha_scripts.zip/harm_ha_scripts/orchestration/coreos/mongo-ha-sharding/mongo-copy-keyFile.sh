#!/bin/bash
#******OBJECTIVE of this file copy mongodb-keyfile to all the machines of the given meta type

#****** SAMPLE META-TYPES are api, api_shadow, mongo_conf , streaming etc

metaType=${1} #****** EXPECTS INPUT which will be the metatype of the machine
pemFileName=${2}

pemFilePath="/home/core/.ssh/"${2}

if [ -z "$metaType" ] || [ -z "$pemFileName" ]  ;
then
scriptUsage="Script usage:  $0 mongo_conf pemFileName"
  echo "one or more required arguments missing for $0 script; $scriptUsage"
  exit 1
fi

if [ -e mongodb-keyfile ]
then
    echo "mongodb-keyfile exists"
else
        echo "ERROR !!! mongodb-keyfile missing. Please run the script create-mongodb-keyfile.sh first"
        exit 1
fi

etcd1=`fleetctl list-machines|grep etcd|awk '{print $2}'| awk  NR==1'{print $1}'`
etcd2=`fleetctl list-machines|grep etcd|awk '{print $2}'| awk  NR==2'{print $1}'`
etcd3=`fleetctl list-machines|grep etcd|awk '{print $2}'| awk  NR==3'{print $1}'`
 
echo "Detecting $metaType nodes"
fleetctl list-machines|grep $metaType,|awk '{print $2}' | sort | paste -d " " -s  > $metaType-cluster.txt
etcdctl --endpoints "http://$etcd1:2379,http://$etcd2:2379,http://$etcd3:2379" set /ips/$metaType "$(cat $metaType-cluster.txt)"
echo "$metaType nodes: $(cat $metaType-cluster.txt)"

count=""$(etcdctl --endpoints "http://$etcd1,http://$etcd2:2379,http://$etcd3:2379" get /ips/$metaType | wc -w)"";

if [[ $count -gt 0 ]]
then
    echo "$metaType Discovery successfull"
else
        echo "ERROR !!! $metaType Discovery FAILED. Please check if nodes of meta type $metaType exists"
        exit 1
fi


copy_keyfile()
{
        node=$1;
        metatypenode=""$(etcdctl --endpoints "http://$etcd1:2379,http://$etcd2:2379,http://$etcd3:2379" get /ips/$metaType |awk -v var="$node" '{print $var}')"";
        scp -i $pemFilePath mongodb-keyfile core@$metatypenode:~/
        ssh -A -o 'StrictHostKeyChecking=no' -i $pemFilePath core@$metatypenode "sudo cp mongodb-keyfile /mnt/ebs0/"
        ssh -A -o 'StrictHostKeyChecking=no' -i $pemFilePath core@$metatypenode "sudo chmod 600 /mnt/ebs0/mongodb-keyfile"
        ssh -A -o 'StrictHostKeyChecking=no' -i $pemFilePath core@$metatypenode "sudo chown 999:999 /mnt/ebs0/mongodb-keyfile"
        echo "Copied mongodb-keyfile to $metatypenode"
}
for i in $(seq 1 $count); do copy_keyfile $i; done