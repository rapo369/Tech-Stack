metaType=${1}

if [ -z "$metaType" ] ;
then
scriptUsage="Script usage:  $0 mongo_conf "
echo "Argument metaType missing for $0 script; $scriptUsage"
  exit 1
fi

etcd1=`fleetctl list-machines|grep etcd|awk '{print $2}'| awk  NR==1'{print $1}'`
etcd2=`fleetctl list-machines|grep etcd|awk '{print $2}'| awk  NR==2'{print $1}'`
etcd3=`fleetctl list-machines|grep etcd|awk '{print $2}'| awk  NR==3'{print $1}'`
 
echo "Detecting $metaType nodes"
fleetctl list-machines|grep $metaType,|awk '{print $2}' | sort | paste -d " " -s  > $metaType-cluster.txt
etcdctl --endpoints "http://$etcd1:2379,http://$etcd2:2379,http://$etcd3:2379" set /ips/$metaType "$(cat $metaType-cluster.txt)"
echo "$metaType nodes: $(cat $metaType-cluster.txt)"

count=""$(etcdctl --endpoints "http://$etcd1,http://$etcd2:2379,http://$etcd3:2379" get /ips/$metaType | wc -w)"";

if [[ $count -gt 0 ]]
then
    echo "$metaType Discovery successfull"
else
        echo "ERROR !!! $metaType Discovery FAILED. Please check if nodes of meta type $metaType exists"
        exit 1
fi