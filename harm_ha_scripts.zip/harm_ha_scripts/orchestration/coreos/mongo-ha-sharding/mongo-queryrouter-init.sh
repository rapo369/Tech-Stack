
tenant=${1}
env=${2}
service=${3}
numberOfShards=${4}
pemFileName=${5}

database=$tenant$env

if [ -z "$tenant" ] || [ -z "$env" ]|| [ -z "$service" ]|| [ -z "$numberOfShards" ]|| [ -z "$pemFileName" ] ;
then
scriptUsage="Script usage:  $0 harman dev mongo_qr_api 2 harpem.pem"
  echo "one or more required arguments missing for $0 script; $scriptUsage"
  exit 1
fi

if [ "${numberOfShards}" -eq 2 ] || [ "${numberOfShards}" -eq 3 ] ; then
    echo "Number of shards is $numberOfShards"
else
        echo "ERROR !!! Number of shards should be 2 or 3"
        exit 1
fi

pemFilePath="/home/core/.ssh/"$pemFileName

instance=${tenant}_${env}_${service}@1.service
instanceip=""$(fleetctl list-units|grep $instance|awk '{print $2}' | cut -d'/' -f 2 | paste -d " " -s  |awk '{print $1}')""

srd_rs0_1=""$(fleetctl list-units|grep ${tenant}_${env}_mongo_srd_rs0|awk '{print $2}' | cut -d'/' -f 2 | paste -d " " -s  |awk '{print $1}')""
srd_rs1_1=""$(fleetctl list-units|grep ${tenant}_${env}_mongo_srd_rs1|awk '{print $2}' | cut -d'/' -f 2 | paste -d " " -s  |awk '{print $1}')""

ssh_permission=""
#if [ $env == "prod" ]
#then
#		ssh_permission=""
#else
#    	ssh_permission="-A -o 'StrictHostKeyChecking=no' -i $pemFilePath core@"    
#fi

ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 --eval 'db.getSiblingDB(\"admin\").createUser( { user: \"admin\", pwd: \"5D0c72dz4bxl\", roles: [ { role: \"root\", db: \"admin\" }] });'"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'db.createUser({ user: \"haa\", pwd: \"78@jkh#de7u\",roles: [{ role: \"dbOwner\", db: \"$database\" }] });'"

echo "Adding Shards rs0 : $srd_rs0_1 and rs1 : $srd_rs1_1"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'db.adminCommand( { addshard : \"rs0/\"+\"${srd_rs0_1}:27017\" } )';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'db.adminCommand( { addshard : \"rs1/\"+\"${srd_rs1_1}:27017\" } )';"


if [ "${numberOfShards}" -eq 3 ] ; then
echo "Adding the third shard in to configuration"	 
	srd_rs2_1=""$(fleetctl list-units|grep ${tenant}_${env}_mongo_srd_rs2|awk '{print $2}' | cut -d'/' -f 2 | paste -d " " -s  |awk '{print $1}')""
	echo "Adding the third shard $srd_rs2_1 in to configuration"	
	ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'db.adminCommand( { addshard : \"rs2/\"+\"${srd_rs2_1}:27017\" } )';"
fi

echo "Adding Shard to database $database"				
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.enableSharding(\"$database\")';"

echo "Adding Shards to collections"				
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.alerts\",{\"pdid\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.averageDriverScore\",{\"_id\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.config\",{\"pdid\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.curfew\",{\"_id\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.dongleStatusAlert\",{\"_id\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.geoFence\",{\"deviceId\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.idling\",{\"_id\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.locations\",{\"pdid\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.notificationSetUps\",{\"userID\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.notnTokenUserMap\",{\"userID\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.speedLimit\",{\"_id\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.vinMapper\",{\"_id\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.trip\",{\"pdid\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.tow\",{\"_id\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.vehiclesummary\",{\"pdid\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.gesequence\",{\"PDID\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.deviceshadow\",{\"pdid\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.servicerecords\",{\"pdId\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.deviceinfo\",{\"_id\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.fuelLog\",{\"pdId\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.notifConfig\",{\"_id\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.tripLocations\",{\"_id\":\"hashed\"})';"
ssh $ssh_permission$instanceip "docker exec -i ${tenant}_${env}_mongos mongo --port 27018 admin -u admin -p 5D0c72dz4bxl --eval 'sh.shardCollection(\"$database.accidentrecords\",{\"pdId\":\"hashed\"})';"
