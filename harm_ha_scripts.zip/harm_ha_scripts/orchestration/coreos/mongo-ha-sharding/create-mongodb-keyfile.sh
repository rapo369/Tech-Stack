 
openssl rand -base64 741 > mongodb-keyfile
chmod 600 mongodb-keyfile

etcd1=`fleetctl list-machines|grep etcd|awk '{print $2}'| awk  NR==1'{print $1}'`;
etcd2=`fleetctl list-machines|grep etcd|awk '{print $2}'| awk  NR==2'{print $1}'`;
etcd3=`fleetctl list-machines|grep etcd|awk '{print $2}'| awk  NR==3'{print $1}'`;

etcdctl --endpoints "http://$etcd1:2379,http://$etcd2:2379,http://$etcd3:2379" set /keyfile/mongodb-keyfile "$(cat mongodb-keyfile)"

#echo $(etcdctl --endpoints "http://$etcd1:2379,http://$etcd2:2379,http://$etcd3:2379" get /keyfile/mongodb-keyfile)  > foo.txt