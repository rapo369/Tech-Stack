tenant=${1}
env=${2}
shardcount=${3}
pemFileName=${4}

if [ -z "$tenant" ] || [ -z "$env" ] || [ -z "$shardcount" ] || [ -z "$pemFileName" ];
then
scriptUsage="Script usage:  $0 harman dev 2 harpem.pem"
  echo "one or more required arguments missing for $0 script; $scriptUsage"
  exit 1
fi

if [[ $shardcount -gt 1 ]]
then
    echo "Number of shards to be created $shardcount"
else
        echo "ERROR !!! Number of shards should be greater than one"
        exit 1
fi

#*************  STEP 1  *****************
#CREATE MONGODB-KEYFILE WHICH WILL BE USED IN ALL MONGO NODES.
#(NOTE STEP 1 CAN BE SKIPPED IF MONGODB-KEYFILE EXISTS OR THERE IS NO NEED TO OVERWRITE EXISTING FILE) 

./create-mongodb-keyfile.sh
sleep 10
#*************  STEP 2  *****************
#CREATE MONGO SHARDING REPLICATIONSET

create_shard()
{
	./create-mongo-srd-rs.sh $tenant $env $1 $pemFileName;
	sleep 20;
}
count=$((shardcount-1))
for i in $(seq 0 $count); do create_shard $i; done

#*************  STEP 3  *****************
#CREATE MONGO CONFIGURATION REPLICATIONSET

./create-mongo-conf-rs.sh $tenant $env $pemFileName
sleep 20

#*************  STEP 4  *****************
#CREATE MONGO QUERY ROUTERS REPLICATIONSET

./create-mongo-queryrouters.sh $tenant $env streaming $pemFileName
sleep 20
#./create-mongo-queryrouters.sh $tenant $env api $pemFileName
#sleep 20
./create-mongo-queryrouters.sh $tenant $env device_shadow $pemFileName
sleep 20
#*************  STEP 5  *****************
#ENABLING AUTHENTICATION AND ADDING SHARDS TO DATABASE AND COLLECTION

./mongo-queryrouter-init.sh $tenant $env mongo_qr_streaming $shardcount $pemFileName





