
tenant=${1}
env=${2}
rs_number=${3};
pemFileName=${4}

if [ -z "$tenant" ] || [ -z "$env" ] || [ -z "$rs_number" ] || [ -z "$pemFileName" ]  ;
then
scriptUsage="Script usage:  $0 harman dev 0 harpem.pem"
  echo "one or more required arguments missing for $0 script; $scriptUsage"
  exit 1
fi
pemFilePath="/home/core/.ssh/"$pemFileName
rs="rs$rs_number";
# *********STEP 1 COPY KEYFILE TO MONGO SHARD NODES ************

./meta-type-discovery.sh mongo_shard$rs_number
if [ $? -eq 1 ]
then
echo "Exiting mongo_shard$rs_number creation"
 exit 1
fi
sleep 10;
	
# *********STEP  CONFIGURE MONGO SHARD REPLICATION SET  ************   
echo "Started Mongo Sharding $rs"  
./start-mongo_srd_$rs.sh ${tenant} ${env} 1..3 all
sleep 60
	
srd_rs_1=""$(fleetctl list-units|grep ${tenant}_${env}_mongo_srd_$rs|awk '{print $2}' | cut -d'/' -f 2 | paste -d " " -s  |awk '{print $1}')""
srd_rs_2=""$(fleetctl list-units|grep ${tenant}_${env}_mongo_srd_$rs|awk '{print $2}' | cut -d'/' -f 2 | paste -d " " -s  |awk '{print $2}')""
srd_rs_3=""$(fleetctl list-units|grep ${tenant}_${env}_mongo_srd_$rs|awk '{print $2}' | cut -d'/' -f 2 | paste -d " " -s  |awk '{print $3}')""   
echo "Started Mongo Sharding $rs"

#shardRS=${tenant}_${env}_mongo_srd_$rs@1.service
#fleetctl ssh -A ${shardRS} "docker exec -i ${tenant}_${env}_mongod mongo --eval 'rs.initiate({_id: \"$rs\", members: [{ _id : 0, host : \"${srd_rs_1}:27017\" },{ _id : 1, host : \"${srd_rs_2}:27017\" },{ _id : 2, host : \"${srd_rs_3}:27017\" }]});'"
#fleetctl ssh -A ${shardRS} "docker exec -i ${tenant}_${env}_mongod mongo --eval 'rs.status();'"

ssh_permission=""
#if [ $env == "prod" ]
#then
#		ssh_permission=""
#else
#    	ssh_permission="-A -o 'StrictHostKeyChecking=no' -i $pemFilePath core@"    
#fi

ssh $ssh_permission$srd_rs_1 "docker exec -i ${tenant}_${env}_mongod mongo --eval 'rs.initiate({_id: \"$rs\", members: [{ _id : 0, host : \"${srd_rs_1}:27017\" },{ _id : 1, host : \"${srd_rs_2}:27017\" },{ _id : 2, host : \"${srd_rs_3}:27017\" }]});'"
ssh $ssh_permission$srd_rs_1 "docker exec -i ${tenant}_${env}_mongod mongo --eval 'rs.status();'"
			
echo "Configured Mongo Sharding $rs"
