
tenant=${1}
env=${2}
pemFileName=${3}

if [ -z "$tenant" ] || [ -z "$env" ] || [ -z "$pemFileName" ]  ;
then
scriptUsage="Script usage:  $0 harman dev harpem.pem"
  echo "one or more required arguments missing for $0 script; $scriptUsage"
  exit 1
fi

pemFilePath="/home/core/.ssh/"$pemFileName
# *********STEP 1 COPY KEYFILE TO MONGO CONFIGURATION NODES ************

./meta-type-discovery.sh mongo_conf
if [ $? -eq 1 ]
then
echo "Exiting Mongo Config Replication Set creation"
 exit 1
fi

sleep 10;

# *********STEP 2 CONFIGURE MONGO CONFIGURATION SERVER REPLICATION SET ************
./start-mongo_conf_rs.sh ${tenant} ${env} 1..3 all
sleep 60
conf_rs_1=""$(fleetctl list-units|grep ${tenant}_${env}_mongo_conf_rs|awk '{print $2}' | cut -d'/' -f 2 | paste -d " " -s  |awk '{print $1}')"";
conf_rs_2=""$(fleetctl list-units|grep ${tenant}_${env}_mongo_conf_rs|awk '{print $2}' | cut -d'/' -f 2 | paste -d " " -s  |awk '{print $2}')"";
conf_rs_3=""$(fleetctl list-units|grep ${tenant}_${env}_mongo_conf_rs|awk '{print $2}' | cut -d'/' -f 2 | paste -d " " -s  |awk '{print $3}')"";    
echo "Started Mongo Configuration Server Replication Set"

#confRS1=${tenant}_${env}_mongo_conf_rs@1.service
#fleetctl ssh -A ${confRS1} "docker exec -i ${tenant}_${env}_mongod mongo --eval 'rs.initiate({_id: \"crs\",configsvr: true, members: [{ _id : 0, host : \"${conf_rs_1}:27017\" },{ _id : 1, host : \"${conf_rs_2}:27017\" },{ _id : 2, host : \"${conf_rs_3}:27017\" }]});'"
#fleetctl ssh -A ${confRS1} "docker exec -i ${tenant}_${env}_mongod mongo --eval 'rs.status();'"

ssh_permission=""
#if [ $env == "prod" ]
#then
#		ssh_permission=""
#else
#    	ssh_permission="-A -o 'StrictHostKeyChecking=no' -i $pemFilePath core@"    
#fi

ssh $ssh_permission$conf_rs_1 "docker exec -i ${tenant}_${env}_mongod mongo --eval 'rs.initiate({_id: \"crs\",configsvr: true, members: [{ _id : 0, host : \"${conf_rs_1}:27017\" },{ _id : 1, host : \"${conf_rs_2}:27017\" },{ _id : 2, host : \"${conf_rs_3}:27017\" }]});'"
ssh $ssh_permission$conf_rs_1 "docker exec -i ${tenant}_${env}_mongod mongo --eval 'rs.status();'"

echo "Configured Mongo Configuration Server Replication Set "