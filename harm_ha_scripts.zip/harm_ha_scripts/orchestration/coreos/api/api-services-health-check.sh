#!/bin/bash
# This script will be called when new node get added by auto scaling. This checks the health of the api services.
#If api service is not present or failed, start the api service.  

set -e

node_count=`fleetctl list-machines|grep -w api | wc -l`
#service_list=`fleetctl list-units|grep api@ | sed -n "s/.*@\([^\.]*\)\..*/\1/p" | sort`
tenant_name_list=`fleetctl list-units|grep api@ | sed 's/\s\+/ /g'|cut -d ' ' -f1|cut -d'_' -f2`
prefix_name_list=`fleetctl list-units|grep api@ | sed 's/\s\+/ /g'|cut -d ' ' -f1|cut -d'_' -f1|uniq`
service_name_list=`fleetctl list-units|grep api@ | sed 's/\s\+/ /g'|cut -d ' ' -f1|cut -d'@' -f1|uniq`

echo "api_node_count : ${node_count}"
echo "api_tenant_name_list : ${tenant_name_list}"
echo "prefix_name_list : ${prefix_name_list}"
echo "service_name_list : ${service_name_list}"

# monitoring services
now=`date +"%Y-%m-%d:%H:%M:%S"`
echo "New node is up, installing service at ${now}... "


for (( count=1 ; ((count-${node_count}-1)) ; count=((${count}+1)) ))
do
    echo "Node : ${count}"
for tenant in ${tenant_name_list}
    do
        echo "Tenant : ${tenant}"
    for prefix in ${prefix_name_list}
        do
            echo "Prefix : ${prefix}"
            service_name_prefix="${prefix}_${tenant}_api"
            if [[ ${service_name_list} =~ (^|[[:space:]])"${service_name_prefix}"($|[[:space:]]) ]] ; then
                echo "Match found : "$service_name_prefix
		        service_name=${service_name_prefix}@${count}.service
		        ## Check Service Status
		        service_status=`fleetctl list-units|grep ^${service_name} | sed 's/\s\+/ /g'|cut -d ' ' -f3`
		        service_status="${service_status#"${var%%[![:space:]]*}"}"
		        if [ -z ${service_status} ] || [ ${service_status} == "failed" ]; then
		                now=`date +"%Y-%m-%d:%H:%M:%S"`
		                echo "${service_name} Service Status at ${now} is ${service_status}"
		                service=`echo ${service_name} |  sed -n "s/.*@\([^\.]*\)\..*/\1/p"`
		                echo "start service is : ${prefix} ${tenant} ${service} all"
		                ./start-api.sh ${prefix} ${tenant} ${service} all
				sleep 10
		        else
		            echo "${service_name} Service Status at ${now} is ${service_status}"
		        fi
		    fi
        done;
    done;
done;

