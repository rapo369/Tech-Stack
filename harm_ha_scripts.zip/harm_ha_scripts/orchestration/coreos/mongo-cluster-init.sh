#!/bin/bash

tenant=${1}
env=${2}
password=${3}

if [ -z "$tenant" ] || [ -z "$env" ]  ;
then
scriptUsage="Script usage:  $0 harman dev"
  echo "one or more required arguments missing for $0 script; $scriptUsage"
  exit 1
fi

single_instance=mongo@1.service
single_service_instance=${tenant}_${env}_${single_instance}

instance=mongo_rs@1.service
service_instance=${tenant}_${env}_${instance}

echo "mongo single service: $single_instance"
echo "mongo primary service: $service_instance"
db_name=${tenant}${env}
echo "db name : $db_name"


status=$(fleetctl ssh -A $service_instance "docker exec -i harman_${env}_mongod mongo admin -u admin -p $password --eval 'rs.status();'" | grep ok | cut -d ':' -f 2 | cut -d ',' -f1 | tr -d '[:space:]')
echo "status:$status";

if [ ${status} -eq 0 ] ; then
    	
	echo "Detecting mongo nodes"
	fleetctl list-machines|grep mongo|awk '{print $2}' | sort | paste -d " " -s  > mongo-cluster.txt
	etcdctl --endpoints "http://10.0.0.6:2379,http://10.0.0.7:2379,http://10.0.0.8:2379" set /ips/mongonodes "$(cat mongo-cluster.txt)"
	echo "mongo nodes: $(cat mongo-cluster.txt)"
	mongonode1=""$(etcdctl --endpoints "http://10.0.0.6:2379,http://10.0.0.7:2379,http://10.0.0.8:2379" get /ips/mongonodes |awk '{print $1}')""
	mongonode2=""$(etcdctl --endpoints "http://10.0.0.6:2379,http://10.0.0.7:2379,http://10.0.0.8:2379" get /ips/mongonodes |awk '{print $2}')""
	mongonode3=""$(etcdctl --endpoints "http://10.0.0.6:2379,http://10.0.0.7:2379,http://10.0.0.8:2379" get /ips/mongonodes |awk '{print $3}')""
	echo $mongonode1
	echo $mongonode2
	echo $mongonode3
    openssl rand -base64 741 > mongodb-keyfile
    chmod 600 mongodb-keyfile
    
    scp mongodb-keyfile core@$mongonode1:~/
    ssh -A core@$mongonode1 "sudo cp mongodb-keyfile /mnt/ebs0/" 
    ssh -A core@$mongonode1 "sudo chmod 600 /mnt/ebs0/mongodb-keyfile" 
    ssh -A core@$mongonode1 "sudo chown 999:999 /mnt/ebs0/mongodb-keyfile" 
    
    echo "Copied mongodb-keyfile to mongonode1"
    
    scp mongodb-keyfile core@$mongonode2:~/
    ssh -A core@$mongonode2 "sudo cp mongodb-keyfile /mnt/ebs0/" 
    ssh -A core@$mongonode2 "sudo chmod 600 /mnt/ebs0/mongodb-keyfile" 
    ssh -A core@$mongonode2 "sudo chown 999:999 /mnt/ebs0/mongodb-keyfile" 
    
    echo "Copied mongodb-keyfile to mongonode2"
    
    scp mongodb-keyfile core@$mongonode3:~/
    ssh -A core@$mongonode3 "sudo cp mongodb-keyfile /mnt/ebs0/" 
    ssh -A core@$mongonode3 "sudo chmod 600 /mnt/ebs0/mongodb-keyfile" 
    ssh -A core@$mongonode3 "sudo chown 999:999 /mnt/ebs0/mongodb-keyfile" 
	
	echo "Copied mongodb-keyfile to mongonode3"
	
	./start-mongo.sh ${tenant} ${env} 1 cascade
	
	sleep 60
	
	echo "Started Mongo as single node"
	
    fleetctl ssh -A ${single_service_instance} "docker exec -i harman_${env}_mongod mongo admin --eval 'db.createUser( { user: \"admin\", pwd: \"$password\", roles: [ { role: \"root\", db: \"admin\" }] });'"
    
    echo "MongoDB admin created"
    
    fleetctl destroy ${single_service_instance}
    
    sleep 10
    
    echo "Mongo single node instance destroyed"
    
	./start-mongo_rs.sh ${tenant} ${env} 1 cascade
    
    echo "Started Mongo Replication Set Primary"
    
    sleep 60
    
    #fleetctl ssh -A $service_instance "docker exec -i harman_${env}_mongod mongo admin -u admin -p $password --eval 'rs.initiate();'"
    fleetctl ssh -A $service_instance "docker exec -i harman_${env}_mongod mongo admin -u admin -p $password --eval 'rs.initiate({_id: \"rs0\", members: [{_id: 0,host: \"$mongonode1:27017\"}]});'"
    fleetctl ssh -A $service_instance "docker exec -i harman_${env}_mongod mongo admin -u admin -p $password --eval 'rs.status();'"
    fleetctl ssh -A $service_instance "docker exec -i harman_${env}_mongod mongo admin -u admin -p $password --eval 'rs.conf();'"
	
	echo "Configured Mongo Replication Set Primary"
	
	fleetctl destroy ${service_instance}
	./start-mongo_rs.sh ${tenant} ${env} 1..3 cascade
	
	sleep 180
	echo "Started Mongo cluster"
	
	
    fleetctl ssh -A $service_instance "docker exec -i harman_${env}_mongod mongo admin -u admin -p $password --eval 'rs.add(\"$mongonode2\");'";
	fleetctl ssh -A $service_instance "docker exec -i harman_${env}_mongod mongo admin -u admin -p $password --eval 'rs.add(\"$mongonode3\");'";
	fleetctl ssh -A $service_instance "docker exec -i harman_${env}_mongod mongo admin -u admin -p $password --eval 'rs.status();'";
	echo "Adding slaves to mongo cluster"
else
    echo "rs.initiate() performed on Mongo cluster "
fi

