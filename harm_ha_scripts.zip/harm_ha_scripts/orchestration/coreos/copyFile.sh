#!/bin/bash
#this script copies the file to the bastion at the desired path

set -e

BASTION_IP=${1}
BASTION_USER=${2}
PRIVATE_KEY=${3}
LOCK_DIR_PATH=${4}
SERVICE_FILE_NAME=${5}
PATH=${6}
DEPLOYER_PATH=${7}
INSTANCES=${8}
CHANGE_DIR=${9}

export PATH=$PATH:/usr/bin:/bin
function usage() {

echo "Script requires 5 arguments in the following order:
     1. IP address of the bastion 
     2. User of the bastion 
     3. Private key for doing ssh and scp 
     4. A path using which directory will be created, which will be used as lock file 
     5. The name of the service file which will be copied from jenkins to the bastion 
     6. Path where the service file will be copied in the bastion
     7. path on bastion where service files needs to created for redeployment
     8. The number of instance of the service to be deployed  
     Example : ./copyFile.sh 1.1.1.1 core haaDev001.pem /home/core/lockDir services.txt /home/core"
    
}

if [ -z "$BASTION_IP" ] || [ -z "$BASTION_USER" ]|| [ -z "$PRIVATE_KEY" ] || [ -z "$LOCK_DIR_PATH" ]|| [ -z "$SERVICE_FILE_NAME" ] || [ -z "$PATH" ] || [ -z "$DEPLOYER_PATH" ] || [ -z "$INSTANCES" ] ;
then
echo "one or more required arguments missing for $0 script"
usage
exit 1
fi

END=$((SECONDS+1200))
while [ $SECONDS -lt $END ]; do

if `/usr/bin/ssh -o 'StrictHostKeyChecking=no' -i ${PRIVATE_KEY}  -q  ${BASTION_USER}@$BASTION_IP stat $LOCK_DIR_PATH \> /dev/null 2\>\&1`
then
	echo "Zzzzzz (*yawns*)"
	/bin/sleep 60
else
	echo "Creating lock directory $LOCK_DIR_PATH"
	/usr/bin/ssh -o 'StrictHostKeyChecking=no' -i ${PRIVATE_KEY} -q  ${BASTION_USER}@${BASTION_IP}  /bin/mkdir -p  $LOCK_DIR_PATH \> /dev/null 2\>\&1
	
	echo "Creating deployer directory $DEPLOYER_PATH"
	/usr/bin/ssh -o 'StrictHostKeyChecking=no' -i ${PRIVATE_KEY} -q  ${BASTION_USER}@${BASTION_IP}  /bin/mkdir -p  $DEPLOYER_PATH \> /dev/null 2\>\&1
            
	service=`echo ${SERVICE_FILE_NAME} | /usr/bin/cut -d '@' -f 1`
	
	service_instance=${service}@$INSTANCES.service
	#copying start script to jenkins
	script_instance=`echo ${SERVICE_FILE_NAME} | /usr/bin/cut -d '_' -f3-`
	script_suffix=`echo ${script_instance} | cut -d "@" -f 1`
	SERVICE_START_SCRIPT=start-${script_suffix}.sh
	
	echo "service file and start script copying to the jenkins ${SERVICE_START_SCRIPT}  ${SERVICE_FILE_NAME}"
	/usr/bin/scp -i ${PRIVATE_KEY}  ${SERVICE_START_SCRIPT}  ${BASTION_USER}@${BASTION_IP}:${BASTION_COPY_PATH}
	
	/usr/bin/scp -i ${PRIVATE_KEY}  ${CHANGE_DIR}/${SERVICE_FILE_NAME}  ${BASTION_USER}@${BASTION_IP}:${BASTION_COPY_PATH}
	
	echo "creating a file in deployer path: ${DEPLOYER_PATH}/${service_instance}"
    /usr/bin/ssh -o 'StrictHostKeyChecking=no' -i ${PRIVATE_KEY} -q  ${BASTION_USER}@${BASTION_IP}  /usr/bin/touch ${DEPLOYER_PATH}/${service_instance} \> /dev/null 2\>\&1
	
	echo "Deployment successful"
    
	echo "Deleting lock file"
	/usr/bin/ssh -o 'StrictHostKeyChecking=no' -i ${PRIVATE_KEY}  -q ${BASTION_USER}@${BASTION_IP}  /bin/rm -rf   $LOCK_DIR_PATH \> /dev/null 2\>\&1
	exit 0
 fi
 done
echo  "Deployment unsuccessful as not able to copy ${FILE_NAME} to bastion"
exit 1
