#!/bin/bash
set -e

#
#create_topic.sh -t harman -e prod  

while getopts "t:e:" opt; do
    case "$opt" in
    t) TENANT=$OPTARG
    ;;
    e) ENV=$OPTARG
    ;;
    esac
done

PREFIX=haa-

./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 1000012   -f $PREFIX -e $ENV -t $TENANT  -i 1 -c  producer  -n post-alerts  -o yes
./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 1000012   -f $PREFIX -e $ENV -t $TENANT  -i 1 -c  producer  -n haa-internal  -o yes
./create-topic.sh  -p 25 -r 2 -l 31536000000 -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n mqtt-kafka-connect-configs -o yes
./create-topic.sh  -p 25 -r 2 -l 172800000   -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n mqtt-kafka-connect-offsets -o yes
./create-topic.sh  -p 25 -r 2 -l 31536000000 -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n mqtt-kafka-status-default -o yes
./create-topic.sh  -p 25 -r 2 -l 172800000   -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n rawmqttalerts -o yes
./create-topic.sh  -p 25 -r 2 -l 172800000   -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n rawmqttalerts-pulse -o yes
./create-topic.sh  -p 25 -r 2 -l 172800000   -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n alerts-dead-letters -o yes
./create-topic.sh  -p 25 -r 2 -l 172800000   -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n rawmqttconfig -o yes
./create-topic.sh  -p 25 -r 2 -l 172800000   -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n rawmqttevents -o yes
./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n notification-state-store -o yes
./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n trip-analysis-alerts -o yes
./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n pdid-to-vin -o yes
./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n driver-score -o yes
./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n kafka-mongodb-connect-configs -o yes
./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n kafka-mongodb-connect-offsets -o yes
./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n kafka-mongodb-status-default -o yes
./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n mongodb-notification-csd-sink -o yes
./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n processed-alerts -o yes
./create-topic.sh  -p 25 -r 2 -l 172800000   -b 1000012   -f $PREFIX  -e $ENV -t $TENANT  -i 1 -c  producer -n test -o no
./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 20000240 -e $ENV -t $TENANT  -i 1 -c  producer -n trip-analysis-mongo -d compact -o yes
./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 1000012  -e $ENV -t $TENANT  -i 1 -c  producer -n pulse-fmdbt-changelog -d compact -o yes
./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 1000012  -e $ENV -t $TENANT  -i 1 -c  producer -n kafka-redis-connector-kafka-redis-state-store-changelog -d compact -o yes      
./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 1000012  -e $ENV -t $TENANT  -i 1 -c  producer -n vehicle_notification_processor-notification-state-store-changelog -d compact -o yes                                                                                                       

#For Ignite
./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 20000240  -e $ENV -t $TENANT  -i 1 -c  producer -n dead-letters -d compact -o yes                                                                                                       
./create-topic.sh  -p 1 -r 2 -l 4147200000  -b 20000240  -e $ENV -t $TENANT  -i 1 -c  producer -n connect-configs -d compact -o yes                                                                                                       
./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 20000240  -e $ENV -t $TENANT  -i 1 -c  producer -n connect-offsets -d compact -o yes                                                                                                       
./create-topic.sh  -p 25 -r 2 -l 4147200000  -b 20000240  -e $ENV -t $TENANT  -i 1 -c  producer -n connect-status -d compact -o yes                                                                                                       