#!/bin/bash
tenant=${1}
env=${2}
PORT=${3}

export KAFKA_MONGODB_CONNECTOR_IP=$(fleetctl list-units|grep ${tenant}_${env}_kafka_mongodb_connect|head -1|awk '{print $2}'|awk -F/ '{print $2}')

script_path=./
json_mongo_hosts=`cat $script_path/${tenant}-${env}-kafka-mongodb-connect.json | grep "hosts" `
export MONGO_CLUSTER_IPS=$(fleetctl list-units|grep _mongo_rs@*|awk '{print $2}'|awk -F/ '{print $2}' | sed -e 's/$/:27017/' | paste -sd ",")
IPS='"'$MONGO_CLUSTER_IPS'",'
HOSTS='"'hosts'":'
MONGO_CLUSTER_IPS=$HOSTS$IPS
echo "MONGO_CLUSTER_IPS:$MONGO_CLUSTER_IPS"

sed -i -e "s/$json_mongo_hosts/$MONGO_CLUSTER_IPS/" ${tenant}-${env}-kafka-mongodb-connect.json
json_mongo_host1=`cat $script_path/${tenant}-${env}-kafka-mongodb-connect.json | grep "hosts" | cut -d ':' -f 2`
echo "Mongo host in json file:$json_mongo_host1"

echo "Current list of connectors"
curl -X GET -H "Content-Type: application/json"  http://${KAFKA_MONGODB_CONNECTOR_IP}:$PORT/connectors
echo "Deleting connector"
curl -X DELETE -H "Content-Type: application/json"  http://${KAFKA_MONGODB_CONNECTOR_IP}:$PORT/connectors/${tenant}${env}kafkamongodbconnector
echo "Deploying Kafka MongoDB connector"
curl -X POST -H "Content-Type: application/json" --data @${tenant}-${env}-kafka-mongodb-connect.json http://${KAFKA_MONGODB_CONNECTOR_IP}:$PORT/connectors
echo "Sleeping for 5 seconds"
sleep 5
echo "Current list of connectors"
curl -X GET -H "Content-Type: application/json"  http://${KAFKA_MONGODB_CONNECTOR_IP}:$PORT/connectors