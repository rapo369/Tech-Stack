#!/bin/bash
tenant=${1}
env=${2}
PORT=${3}

export MQTT_CONNECTOR_IP=$(fleetctl list-units|grep ${tenant}_${env}_mqtt_kafka_connector|head -1|awk '{print $2}'|awk -F/ '{print $2}')
export MQTT_BROKER_IP=$(fleetctl list-units|grep mqtt@.*.service|head -1|awk '{print $2}'|awk -F/ '{print $2}')
echo "One MQTT connector IP: ${MQTT_CONNECTOR_IP} MQTT_BROKER_IP: $MQTT_BROKER_IP"
echo "Sleeping for 30 seconds to allow the connector to start"
sleep 30
echo "Current list of connectors"
curl -X GET -H "Content-Type: application/json"  http://$MQTT_CONNECTOR_IP:$PORT/connectors
echo "Deleting connector"
curl -X DELETE -H "Content-Type: application/json"  http://$MQTT_CONNECTOR_IP:$PORT/connectors/${tenant}${env}mqttconnector
sed -i -e "s/\${MQTT_BROKER_IP}/$MQTT_BROKER_IP/" ${tenant}-${env}-mqttkafkaconnectconfig.json
echo "Deploying mqtt kafka connector"
curl -X POST -H "Content-Type: application/json" --data @${tenant}-${env}-mqttkafkaconnectconfig.json http://$MQTT_CONNECTOR_IP:$PORT/connectors
echo "Sleeping a few seconds"
sleep 5
echo "Current list of connectors"
curl -X GET -H "Content-Type: application/json"  http://$MQTT_CONNECTOR_IP:$PORT/connectors