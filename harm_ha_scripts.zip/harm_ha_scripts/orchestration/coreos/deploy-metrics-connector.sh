#!/bin/bash

export CONNECTOR_IP=$(fleetctl list-units|grep metricsconnector|head -1|awk '{print $2}'|awk -F/ '{print $2}')
echo "One metrics persister IP: $CONNECTOR_IP"
echo "Current list of metrics persisters"
curl -X GET -H "Content-Type: application/json"  http://$CONNECTOR_IP:8083/connectors
echo "Deleting metrics persisters"
curl -X DELETE -H "Content-Type: application/json"  http://$CONNECTOR_IP:8083/connectors/mtrcs
export MYSQL_IP=$(fleetctl list-units|grep mysql|awk '{print $2}'|awk -F/ '{print $2}')
etcdctl --endpoints "http://10.0.0.6:2379,http://10.0.0.7:2379,http://10.0.0.8:2379" set /ips/mysql "$(echo $MYSQL_IP)"
sed -i -e "s/\${MYSQL_IP}/$MYSQL_IP/" metricss3connectorconfig.json
echo "Deploying s3 metrics persister streaming app"
curl -X POST -H "Content-Type: application/json" --data @metricss3connectorconfig.json http://$CONNECTOR_IP:8083/connectors
echo "Sleeping a few seconds"
sleep 5
echo "Current list of metrics persisters"
curl -X GET -H "Content-Type: application/json"  http://$CONNECTOR_IP:8083/connectors