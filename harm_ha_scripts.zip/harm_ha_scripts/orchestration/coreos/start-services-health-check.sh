#!/bin/bash

tenant=${1}
env=${2}
instance=services_health_check@1.service

service_instance=${tenant}_${env}_${instance}

cnt1=`ps -ef |grep -v grep |grep -c "/services-health-check.sh"`
if [ $cnt1 -eq 1 ]
then
echo "${service_instance} is already running."
exit
else
# if services-health-check.sh is not running thern service restarting.

echo "Starting health check service"
fleetctl submit ${service_instance}
fleetctl start ${service_instance}

unit_name=`echo $service_instance | cut -d '@' -f 1`
no_of_units=`echo $service_instance | awk -v FS="({|})" '{print $2}' | cut -d '.' -f 3`
no_of_units="${no_of_units#"${var%%[![:space:]]*}"}"
if [ "$no_of_units" == "" ];then
   no_of_units=1
fi
 
rc=0
iterations=1
max_tries=20 
while [ $rc -lt $no_of_units ]
do
echo "Zzzzzz (*yawns*)"
rc=$(fleetctl list-units|grep ${unit_name}@| grep running|wc -l)
fleetctl list-units|grep ${unit_name}@
iterations=`expr $iterations + 1`
if [ "$iterations" -gt "$max_tries" ];then
   echo "start script exceeded max number of retries will exit"
   exit 1
fi
sleep 1;

done
fi
echo "${service_instance} is running"
