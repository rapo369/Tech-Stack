#!/bin/bash

echo "Detecting log manager"
fleetctl list-machines | grep graylog | awk '{print $2}'|paste -d " " -s  > graylog-node.txt
etcdctl --endpoints "http://10.0.0.6:2379,http://10.0.0.7:2379,http://10.0.0.8:2379" set /ips/graylognode "$(cat graylog-node.txt)"
echo "Graylog node $(cat graylog-node.txt)"

echo "Stopping log manager"
fleetctl destroy graylog2@1.service
fleetctl destroy graylog2-es@1.service
fleetctl destroy graylog2-mongo@1.service

echo "Starting log manager"
fleetctl submit graylog2-mongo@1.service
fleetctl start graylog2-mongo@1.service
fleetctl submit graylog2-es@1.service
fleetctl start graylog2-es@1.service
fleetctl submit graylog2@1.service
fleetctl start graylog2@1.service