#!/bin/bash
CURRENT_DIR=$(dirname $0)
cd $CURRENT_DIR

#registering services-health-check.timer 
sudo cp harman_prod_services_health_check.timer /etc/systemd/system
sudo cp harman_prod_services_health_check.service /etc/systemd/system

sudo systemctl stop harman_prod_services_health_check.timer
sudo systemctl start harman_prod_services_health_check.timer

echo "services-health-check.timer is started" 
