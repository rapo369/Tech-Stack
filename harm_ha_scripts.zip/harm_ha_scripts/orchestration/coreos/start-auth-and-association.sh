#!/bin/bash

fleetctl destroy postgres_hcp@1.service
fleetctl destroy auth@1.service
fleetctl destroy user_auth@1.service
fleetctl destroy association@1.service
fleetctl destroy device_info@1.service

echo "Starting postgres service."
fleetctl submit postgres_hcp@1.service
fleetctl start postgres_hcp@1.service

echo "Starting auth service."
fleetctl submit auth@1.service
fleetctl start auth@1.service

echo "Starting postgres service."
fleetctl submit user_auth@1.service
fleetctl start user_auth@1.service

echo "Starting association service."
fleetctl submit association@1.service
fleetctl start association@1.service

echo "Starting device_info service."
fleetctl submit device_info@1.service
fleetctl start device_info@1.service


rc=0
while [ $rc -lt 5 ]
do
echo "Zzzzzz (*yawns*)"
sleep 5
rc=$(fleetctl list-units|grep -E 'auth@.*.service|association@*.service|device_info@*.service|user_auth@*.service|postgres_hcp@*.service'|grep running|wc -l)
fleetctl list-units|grep -E 'auth@.*.service|association@*.service|device_info@*.service|user_auth@*.service|postgres_hcp@*.service'
done
echo "Hcp services are ready.."
