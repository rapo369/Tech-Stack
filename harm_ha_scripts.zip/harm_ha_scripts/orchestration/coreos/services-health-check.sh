#!/bin/bash
############################################################################################
#Add entry to the services.txt file for a new service that needs to be monitored for failure

############################################################################################
iterations=1
while [ $iterations -lt 2 ]
do

	## list of the failed services
	SERVICES_LIST_FILE=${1}
	CURRENT_DIR=$(dirname $0)
	cd $CURRENT_DIR

	# monitoring services
	now=`date +"%Y-%m-%d:%H:%M:%S"`
	echo "Started Monitoring services defined in services.txt file at $now"

	#delete empty row from {SERVICES_LIST_FILE} file
	sed -i '/^$/d' ${SERVICES_LIST_FILE}
	failed_services_count=`fleetctl list-units|sed 's/\s\+/ /g'|cut -d ' ' -f3 | grep "failed" | wc -l`
	now=`date +"%Y-%m-%d:%H:%M:%S"`
	echo "no of failed services at $now is $failed_services_count"

	while read -r servicename
	do
		## Check Service Status
		service_status=`fleetctl list-units|grep ^${servicename} | sed 's/\s\+/ /g'|cut -d ' ' -f3`
		service_status="${service_status#"${var%%[![:space:]]*}"}"

		#echo "${servicename} Service Status is $service_status"
		if [ "$service_status" == "" ] || [ "$service_status" == "failed" ];
		then
			now=`date +"%Y-%m-%d:%H:%M:%S"`
			echo "${servicename} Service Status at $now is $service_status"
			echo "Subject: SaaS Service Failure Alert" > /tmp/service_failed;
			echo "${servicename} Service is failed/not started" >> /tmp/service_failed;
			docker run -t=false -i busybox sendmail -S nagios.ahanet.net -f no-reply@harman.com HCP_Data_Support@harman.com  < /tmp/service_failed
			rm /tmp/service_failed

		fi
	done < ${SERVICES_LIST_FILE}

	sleep 10
done

