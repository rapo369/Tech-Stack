#!/bin/bash

tenant=${1}
env=${2}
instance=${3}
service=`(echo $0 | sed -e "s/.\/start-//g")`
service=`(echo $service | sed -e "s/.sh//g")`
case ${3} in
''|*[!0-9]*) 
  instance1=`(echo $3 | cut -d '.' -f 1  )` ;
  instancen=`(echo $3 | cut -d '.' -f 3  )` ;;
*) 
  instance1=$3 ;
  instancen=$3 ;;
esac

if [ -z "$tenant" ] || [ -z "$env" ] || [ -z "$instance" ] || [ -z "$4" ]  ;
then
scriptUsage="Script usage:  $0 harman dev 1..2 all|cascade"
  echo "one or more required arguments missing for $0 script; $scriptUsage"
  exit 1
fi
if [ "$4" = "all" ]
then
 service_instance_all=""
 for i in `seq $instance1 $instancen`
 do
  instance=$service@$i
  service_instance=${tenant}_${env}_${instance}
  service_instance_all="${service_instance_all} ${service_instance}"
 done

 echo "Shutting down $service service : ${service_instance_all}"
 fleetctl destroy ${service_instance_all}

 echo "Starting $service service : ${service_instance_all}"
 fleetctl submit ${service_instance_all}
 fleetctl start ${service_instance_all}

elif [ "$4" = "cascade" ]
then

for i in `seq $instance1 $instancen`
do
instance=$service@$i 
service_instance=${tenant}_${env}_${instance}
echo "--------------------------"

echo "Destroying Redis: ${service_instance}"

fleetctl destroy ${service_instance}
if [ $? == 0 ] ; then
    echo "Sleeping 20 seconds..."
    sleep 20
fi

echo "Starting Redis: ${service_instance}"
fleetctl submit ${service_instance}
fleetctl start ${service_instance}

done
else
    echo "Invalid restart mode"
    exit 1;
fi

echo "--------------------------"
unit_name=`echo $service_instance | cut -d '@' -f 1`
no_of_units=`expr $instancen + 1 - $instancen`
if [ "$no_of_units" == "" ];then
   no_of_units=1
fi

rc=0
iterations=1
max_tries=10 
while [ $rc -lt $no_of_units ]
do
echo "Zzzzzz (*yawns*)"
sleep 5
rc=$(fleetctl list-units|grep ${unit_name}@|grep running|wc -l)
fleetctl list-units|grep ${unit_name}@

iterations=`expr $iterations + 1`
if [ "$iterations" -gt "$max_tries" ];then
   echo "start script exceeded max number of retries will exit"
   exit 1
fi

done
echo "Redis sentinel is ready"

 echo "Detecting sentinel nodes"
        fleetctl list-units|grep sentinel@|awk '{print $2}'|awk -F/ '{print $2}' | paste -d " " -s  > sentinel-cluster.txt
        etcd1=`fleetctl list-machines|grep etcd|awk '{print $2}'| awk  NR==1'{print $1}'`
		etcd2=`fleetctl list-machines|grep etcd|awk '{print $2}'| awk  NR==2'{print $1}'`
		etcd3=`fleetctl list-machines|grep etcd|awk '{print $2}'| awk  NR==3'{print $1}'`
        etcdctl --endpoints "http://$etcd1:2379,http://$etcd2:2379,http://$etcd3:2379" set /ips/sentinelnodes "$(cat sentinel-cluster.txt)"
echo "sentinel nodes: $(cat sentinel-cluster.txt)"