#!/bin/bash
cd /home/core

tenant=${1}
env=${2}

for tenant_name in $(echo ${tenant} | sed "s/,/ /g")
do
  echo "Script is running for tenant : $tenant_name"


#Stop servicecs---------------------------------------------------------------------------
echo "@5 Stopping streaming apps------------------------------------------------------------"
echo "   ${tenant_name}_${env}_kafka_redis_connector@1.service"
fleetctl destroy ${tenant_name}_${env}_kafka_redis_connector@1.service
sleep 10;

echo "@4 Stopping Notification  service-----------------------------------------------------"
echo "   ${tenant_name}_${env}_vehicle_notification_processor@1.service"
fleetctl destroy ${tenant_name}_${env}_vehicle_notification_processor@1.service
sleep 10;

echo "@3 Stopping Connectors service--------------------------------------------------------"
echo "   ${tenant_name}_${env}_kafka_mongodb_connect@1.service"
fleetctl destroy ${tenant_name}_${env}_kafka_mongodb_connector@1.service
sleep 10;

echo "   ${tenant_name}_${env}_kafka-s3-legacy-connector service"
fleetctl destroy ${tenant_name}_${env}_kafka_s3_legacy_connector@1.service
fleetctl destroy ${tenant_name}_${env}_kafka_s3_legacy_connector@2.service
sleep 10;

echo "   ${tenant_name}_${env}_dtc_data_loader@.service"
fleetctl destroy ${tenant_name}_${env}_dtc_data_loader@1.service
sleep 10;

echo "   ${tenant_name}_${env}_mqttbridge@1.service"
fleetctl destroy ${tenant_name}_${env}_mqtt_kafka_connector@1.service
sleep 10;



echo ""
##----------------------------------------------------------------------------------------------

echo "@1 Starting ${tenant_name}_${env}_zookeeper@ service-------------------------------"
./start-zookeeper.sh ${tenant_name} ${env} zookeeper@1.service
./start-zookeeper.sh ${tenant_name} ${env} zookeeper@2.service
./start-zookeeper.sh ${tenant_name} ${env} zookeeper@3.service

echo "@2 Starting ${tenant_name}_${env}_kafka service-------------------------------------------"
./start-kafka.sh ${tenant_name} ${env} kafka@1.service
./start-kafka.sh ${tenant_name} ${env} kafka@2.service
./start-kafka.sh ${tenant_name} ${env} kafka@3.service

echo "@3 Starting Connectors service------------------------------------------------------------"

echo "   Starting ${tenant_name}_${env}_kafka_mongodb_connect@1.service"
./start-kafka_mongodb_connector.sh ${tenant_name} ${env} kafka_mongodb_connector@1.service

echo "   Starting ${tenant_name}_${env}_kafka-s3-legacy-connector@.service"
./start-kafka_s3_legacy_connector.sh ${tenant_name} ${env} kafka_s3_legacy_connector@1.service
./start-kafka_s3_legacy_connector.sh ${tenant_name} ${env} kafka_s3_legacy_connector@2.service

echo "   Starting ${tenant_name}_${env}_dtc_data_loader@1.service"
./start-dtc_data_loader.sh ${tenant_name} ${env} dtc_data_loader@1.service

echo "   Starting MQTT Kafka Connector (mqttbridge@1.service)"
./start-mqtt_kafka_connector.sh ${tenant_name} ${env} mqtt_kafka_connector@1.service

echo "@4 Starting Notification  service--------------------------------------------------------"
./start-vehicle_notification_processor.sh ${tenant_name} ${env} vehicle_notification_processor@1.service

echo "@5 Starting streaming apps---------------------------------------------------------------"
./start-kafka_redis_connector.sh ${tenant_name} ${env} kafka_redis_connector@1.service

./start-pulse.sh ${tenant} ${env} pulse@1.service

##-----------------------------------------------------------------------------------------
echo ""
echo "All units"
fleetctl list-units
echo "All machines"
fleetctl list-machines
echo ""
done
echo "script completed................................."
##----------------------------------------------------------------------------------------
