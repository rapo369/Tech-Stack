#!/bin/bash
tenant=${1}
env=${2}

sentinel_instance=${3}
slave_instance=${4}
restart_mode=cascade


./start-redis_ha_master.sh $tenant $env 1 ${restart_mode}
./start-redis_ha_sentinel.sh $tenant $env 1..$sentinel_instance ${restart_mode}
./start-redis_ha_slave.sh $tenant $env 1..$slave_instance ${restart_mode}

