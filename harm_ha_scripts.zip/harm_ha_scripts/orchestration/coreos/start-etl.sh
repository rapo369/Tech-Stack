#!/bin/bash
fleetctl destroy etl@1.service
if [[ $? == 0 ]]; then
echo "Waiting for 60 secs before restarting the ETL service"
sleep 60
fi

echo "Starting ETL service"
fleetctl submit etl@1.service
fleetctl start etl@1.service
echo "Started ETL service. Waiting for container to start"
ec=0
while [ $ec -lt 1 ]
do
echo "Zzzzzz (*yawns*)"
sleep 5
ec=$(fleetctl list-units|grep etl|grep running|wc -l)
fleetctl list-units|grep etl
done
echo "ETL service is ready!"
sleep 30;
echo "logs for etl@1.service-----------------"
fleetctl journal -lines 20 etl@1.service
