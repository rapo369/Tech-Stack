#!/bin/bash

tenant=${1}
env=${2}

echo "Detecting log manager"
fleetctl list-machines | grep graylog | awk '{print $2}'|paste -d " " -s  > graylog-node.txt
etcdctl --endpoints "http://10.140.12.139:2379,http://10.140.12.140:2379,http://10.140.12.141:2379" set /ips/graylognode "$(cat graylog-node.txt)"
echo "Graylog node $(cat graylog-node.txt)"

echo "Stopping log manager"
fleetctl destroy ${tenant}_${env}_graylog2@1.service
if [[ $? == 0 ]]; then
echo "Waiting for 60 secs before restarting the graylog2 service"
sleep 60
fi

fleetctl destroy ${tenant}_${env}_graylog2_es@1.service
if [[ $? == 0 ]]; then
echo "Waiting for 60 secs before restarting the graylog2_es service"
sleep 60
fi

fleetctl destroy ${tenant}_${env}_graylog2_mongo@1.service
if [[ $? == 0 ]]; then
echo "Waiting for 60 secs before restarting the graylog2_mongo service"
sleep 60
fi


echo "Starting log manager"
fleetctl submit ${tenant}_${env}_graylog2_mongo@1.service
fleetctl start ${tenant}_${env}_graylog2_mongo@1.service
sleep 10
fleetctl submit ${tenant}_${env}_graylog2_es@1.service
fleetctl start ${tenant}_${env}_graylog2_es@1.service
sleep 10
fleetctl submit ${tenant}_${env}_graylog2@1.service
fleetctl start ${tenant}_${env}_graylog2@1.service
sleep 180
