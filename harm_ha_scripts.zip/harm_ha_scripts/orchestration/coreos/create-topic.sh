#!/bin/bash
#set -e

#
# create_topic.sh
#

TTL=
REPLICATION_FACTOR=
PARTITION=
TOPIC_NAME=
KAFKA_SERVICE=kafka@1.service
MAX_MESSAGE_BYTES=
ENV=
TENANT=
MIN_INSYNC_REPLICAS=
COMPRESSION_TYPE=
CLEANUP_POLICY=

while getopts "p:r:l:n:b:f:e:t:i:c:d:o:" opt; do
    case "$opt" in
    p) PARTITION=$OPTARG
    ;;
    r) REPLICATION_FACTOR=$OPTARG
    ;;
    l) TTL=$OPTARG
    ;;
    n) TOPIC_NAME=$OPTARG
    ;;
    b) MAX_MESSAGE_BYTES=$OPTARG
    ;;
    f) PREFIX=$OPTARG
    ;;
    e) ENV=$OPTARG
    ;;
    t) TENANT=$OPTARG
    ;;
    i) MIN_INSYNC_REPLICAS=$OPTARG
    ;;
    c) COMPRESSION_TYPE=$OPTARG
    ;;
    d) CLEANUP_POLICY=$OPTARG
    ;;
    o) PREFIX_ENABLED=$OPTARG
    ;;
    esac
done

function SHOW_HELP {
    echo "USAGE: -p <partition> -r <replication factor> -l <ttl> -b<max message byte> -e <env> -t <tenant> -i <in_sync_replicas> -c <compression_type>  -n <topic name> -d <cleanup policy> "
}


if [[ -z "${TOPIC_NAME}" ]]; then
    echo "Must provide Topic Name (e.g., topic_test_dev) with -n <name of the topic>"
    SHOW_HELP
    exit 0
fi
if [[ -z "${TTL}" ]]; then
    echo "Must provide TTL (e.g., 4147200000) with -l <value for TTL>"
    SHOW_HELP
    exit 0
fi
if [[ -z "${PARTITION}" ]]; then

    echo "Must provide Partition (e.g., 25) with -p <value for Partition>"
    SHOW_HELP
    exit 0
fi
if [[ -z "${MAX_MESSAGE_BYTES}" ]]; then
    echo "Must provide max_mesage_bytes (e.g., 1000012) with -b <max message bytes>"
    SHOW_HELP
    exit 0
fi
if [[ -z "${REPLICATION_FACTOR}" ]]; then
    echo "Must provide Replication Factor (e.g., 2) with -r <replication factor>"
    SHOW_HELP
    exit 0
fi
if [[ -z "${ENV}" ]]; then
    echo "Must provide env (e.g., dev) with -e <env>"
    SHOW_HELP
    exit 0
fi
if [[ -z "${TENANT}" ]]; then
    echo "Must provide tenant (e.g., harman) with -t <tenant>"
    SHOW_HELP
    exit 0
fi
if [[ -z "${MIN_INSYNC_REPLICAS}" ]]; then
    echo "Must provide min_insync_replicas (e.g., 1) with -i <in_sync_replicas>"
    SHOW_HELP
    exit 0
fi
if [[ -z "${COMPRESSION_TYPE}" ]]; then
    echo "Must provide compression_type (e.g., gzip) with -c <compression_type>"
    SHOW_HELP
    exit 0
fi

if [ "$PREFIX_ENABLED" == "yes" ] ; then
TOPIC_NAME=$PREFIX"$TENANT"-"$ENV"-"$TOPIC_NAME"
fi

echo TOPIC NAME :  $TOPIC_NAME

KAFKA_SERVICE="$TENANT"_dev_"$KAFKA_SERVICE"

#HAA_zookeeper_connect=10.0.0.139:2181,10.0.0.142:2181,10.0.0.118:2181
HAA_zookeeper_connect=""$(etcdctl --endpoints "http://10.0.0.6:2379,http://10.0.0.7:2379,http://10.0.0.8:2379" get /ips/zoonodes |awk '{print $1}'):2181,$(etcdctl --endpoints "http://10.0.0.6:2379,http://10.0.0.7:2379,http://10.0.0.8:2379" get /ips/zoonodes |awk '{print $2}'):2181,$(etcdctl --endpoints "http://10.0.0.6:2379,http://10.0.0.7:2379,http://10.0.0.8:2379" get /ips/zoonodes |awk '{print $3}'):2181""

#fleetctl ssh $KAFKA_SERVICE  '/bin/bash -c "docker exec \-it kafka kafka-topics --create --topic '$TOPIC_NAME' --if-not-exists  --partitions '$PARTITION' --replication-factor '$REPLICATION_FACTOR' --config retention.ms='$TTL' max.message.bytes='$MAX_MESSAGE_BYTES' min.insync.replicas='$MIN_INSYNC_REPLICAS' compression.type='$COMPRESSION_TYPE'  --zookeeper '$HAA_zookeeper_connect'"' 

if [ "$CLEANUP_POLICY" = "compact" ] || [ "$CLEANUP_POLICY" = "delete" ] ; then
CLEANUP_POLICY_CMD="--config cleanup.policy=$CLEANUP_POLICY --config min.cleanable.dirty.ratio=0.5 --config segment.ms=14400000" 
fi


echo $CLEANUP_POLICY_CMD
kafka-topics --create --topic $TOPIC_NAME --if-not-exists  --partitions $PARTITION --replication-factor $REPLICATION_FACTOR --config retention.ms=$TTL --config max.message.bytes=$MAX_MESSAGE_BYTES --config min.insync.replicas=$MIN_INSYNC_REPLICAS --config compression.type=$COMPRESSION_TYPE  $CLEANUP_POLICY_CMD --zookeeper $HAA_zookeeper_connect 
