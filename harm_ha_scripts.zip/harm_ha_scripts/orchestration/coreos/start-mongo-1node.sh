#!/bin/bash

fleetctl destroy mongo@1.service

fleetctl submit mongo@1.service
sleep 15
fleetctl start mongo@1.service

kc=0
while [ $kc -lt 1 ]
do
echo "Zzzzzz (*yawns*)"
sleep 5
kc=$(fleetctl list-units|grep mongo|grep running|wc -l)
fleetctl list-units |grep mongo
done
echo "Mongo cluster is ready!"

export MONGO_SERVER_IP=$(fleetctl list-units|grep ^mongo@|awk '{print $2}'|awk -F/ '{print $2}')
etcdctl --endpoints "http://10.0.0.6:2379,http://10.0.0.7:2379,http://10.0.0.8:2379" set /ips/mongo "$(echo $MONGO_SERVER_IP)"
echo "Address of mongo server:" $(etcdctl --endpoints "http://10.0.0.6:2379,http://10.0.0.7:2379,http://10.0.0.8:2379" get /ips/mongo |awk '{print $1}')
